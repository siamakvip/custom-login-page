<?php
// wp-load.php را لوود کن (مسیر را بر اساس محیط تست خودت تنظیم کن)
require_once '/path/to/your/wordpress/wp-load.php';